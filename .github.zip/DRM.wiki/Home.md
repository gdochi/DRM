# DRM Wiki / DRM 위키

This wiki is the main manual for the DRM editor family.
이 위키는 DRM 에디터 계열의 메인 사용 설명서입니다.

## Main Category / 메인 카테고리

### Dialogue / 다이얼로그

Dialogue Editor covers NPC conversations, branch choices, conditions, actions, GUI mapping, and runtime testing.
다이얼로그 에디터는 NPC 대화, 분기 선택지, 조건, 액션, GUI 연결, 런타임 테스트를 다룹니다.

[[Dialogue|Open the Dialogue page / 다이얼로그 페이지 열기]]

## Language Support / 언어 지원

This wiki page is written in both English and Korean on the same page.
이 위키는 한 페이지 안에 영어와 한국어를 함께 작성합니다.

## How To Use This Wiki / 위키 사용법

1. Start from this page.
2. Open the category you want.
3. Add screenshots directly in GitHub Wiki when you are ready.
4. Keep the section order stable so readers can follow the same flow every time.

## What Comes Next / 다음 항목

- Dialogue setup and node flow
- GUI mapping notes
- Troubleshooting and common mistakes

오른쪽 카데고리 누르면 raw라고 나와버리는데?
지금 구조말고 웹페이지 처럼은 못만드냐?
그전에 이전에 만든거 줄때 웹페이지처럼 만들었었잖아.
