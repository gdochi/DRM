# Dialogue GUI Mapping / 다이얼로그 GUI 연결

GUI mapping connects a dialogue branch to a custom GUI screen.
GUI 연결은 다이얼로그 분기를 커스텀 GUI 화면과 이어 줍니다.

## What To Match / 맞춰야 할 것

| Item | English | 한국어 |
| --- | --- | --- |
| GUI file path | Must match the exported GUI JSON path. | 내보낸 GUI JSON 경로와 맞아야 합니다. |
| Runtime asset path | Must match the file that runtime loads. | 런타임이 읽는 파일과 맞아야 합니다. |
| Trigger point | Decide whether the GUI opens on entry or on choice. | 진입 시 열지 선택 시 열지 정합니다. |
| Test world | Use the same world you will ship or test in. | 실제 테스트할 월드와 같은 월드를 씁니다. |

## Good Practice / 좋은 사용법

1. Finish the dialogue flow first.
2. Build the GUI next.
3. Connect the mapping last.
4. Test the dialogue and GUI together.
5. Keep screenshots ready for later documentation.

## Common Mistakes / 흔한 실수

- The GUI file path does not match the exported file.
- The dialogue opens the wrong screen.
- The runtime path points to an old file.
- The editor preview and runtime screen do not match.

