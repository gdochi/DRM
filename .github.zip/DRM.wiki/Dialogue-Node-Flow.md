# Dialogue Node Flow / 다이얼로그 노드 흐름

Node flow is the structure that carries the conversation from one line to the next.
노드 흐름은 대화가 한 줄에서 다음 줄로 이어지는 구조입니다.

## Node Types / 노드 종류

| Type | English | 한국어 |
| --- | --- | --- |
| Start node | The first node the player sees. | 플레이어가 처음 보는 노드입니다. |
| Branch node | A node that offers choices. | 선택지를 제공하는 노드입니다. |
| Condition node | A node that appears only in a certain state. | 특정 상태에서만 보이는 노드입니다. |
| Action node | A node that triggers commands or rewards. | 명령이나 보상을 실행하는 노드입니다. |
| End node | A branch ending or exit point. | 분기 종료 또는 나가는 지점입니다. |

## Recommended Shape / 권장 형태

1. Begin with one start node.
2. Keep the first branch obvious.
3. Put special conditions deeper in the tree.
4. Keep one branch for testing and one for the real path.
5. Avoid making a node do too many jobs at once.

## Writing Rules / 작성 규칙

- Name nodes by purpose, not only by line text.
- Keep long story branches separate from utility branches.
- If a node is used for testing, mark it clearly.
- Reorder branches only when the reason is obvious.

