# Dialogue Actions / 다이얼로그 액션

Actions run when a node opens or a choice is selected, depending on the setup.
액션은 설정에 따라 노드가 열릴 때 또는 선택지가 눌릴 때 실행됩니다.

## Action Types / 액션 종류

| Type | English | 한국어 |
| --- | --- | --- |
| Command | Runs a server command or script action. | 서버 명령이나 스크립트 동작을 실행합니다. |
| Item | Gives, removes, or consumes an item. | 아이템을 지급, 제거, 소비합니다. |
| Sound | Plays a sound effect. | 사운드 효과를 재생합니다. |
| State change | Updates tags, flags, or counters. | 태그, 플래그, 카운터를 갱신합니다. |
| GUI open | Opens a custom GUI screen. | 커스텀 GUI 화면을 엽니다. |

## Good Practice / 좋은 사용법

- Use the smallest action set that gets the job done.
- Keep reward actions separate from story actions when possible.
- Make state changes visible in test notes.
- Test command actions in a safe world first.
- Do not stack too many side effects in one node if you can split them.

## Common Mistakes / 흔한 실수

| Mistake | Result | Fix |
| --- | --- | --- |
| Too many actions on one node | Debugging becomes hard. | Split the work into more nodes. |
| Wrong item action | The player gets the wrong item or none. | Recheck the item ID and count. |
| Unexpected command | The wrong runtime effect happens. | Test the command on its own first. |

