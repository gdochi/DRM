# Dialogue Conditions / 다이얼로그 조건

Conditions decide when a node or choice should be shown.
조건은 노드나 선택지가 언제 보여야 하는지 정합니다.

## Typical Condition Types / 대표 조건

| Type | English | 한국어 |
| --- | --- | --- |
| StoredData | Checks saved progress or flags. | 저장된 진행도나 플래그를 확인합니다. |
| Tags | Checks tag state on the player or NPC. | 플레이어 또는 NPC의 태그 상태를 확인합니다. |
| Inventory | Checks whether the player has an item. | 플레이어가 아이템을 가지고 있는지 확인합니다. |
| Currency | Checks whether the player can pay. | 플레이어가 지불 가능한지 확인합니다. |
| Custom logic | Uses mod-specific or pack-specific rules. | 모드나 팩 전용 규칙을 사용합니다. |

## Good Practice / 좋은 사용법

1. Add conditions after the base dialogue path works.
2. Keep condition names readable.
3. Make hidden branches easy to find in the editor.
4. Document why the condition exists.
5. Test both the visible and hidden paths.

## Debug Questions / 점검 질문

- Is the condition attached to the correct node?
- Does the state value actually change in runtime?
- Is the player or NPC object the one you expected?
- Is the branch hidden intentionally or by mistake?

