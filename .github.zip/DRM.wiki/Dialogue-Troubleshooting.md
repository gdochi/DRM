# Dialogue Troubleshooting / 다이얼로그 문제 해결

This page collects common problems and their first fixes.
이 페이지는 자주 발생하는 문제와 1차 해결 방법을 모아둔 페이지입니다.

## Common Issues / 자주 나는 문제

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| Choice does not show | A condition hides it or the target is wrong. | Check the condition and the branch target. |
| Dialogue order feels broken | Node flow is unclear or branches are mixed up. | Review the node tree and rename branches. |
| GUI does not open | The GUI mapping path does not match the file. | Recheck the path and export again. |
| Export fails | A required field is missing. | Fill the missing value and try again. |
| Text drifts between languages | Only one language page was updated. | Update English and Korean together. |

## Debug Order / 점검 순서

1. Confirm the correct node.
2. Confirm the correct target.
3. Confirm the condition.
4. Confirm the action.
5. Confirm the GUI path.
6. Test again in runtime.

