# Dialogue Choices / 다이얼로그 선택지

Choices are the player responses that move a conversation to the next node.
선택지는 대화를 다음 노드로 옮기는 플레이어 응답입니다.

## Fields / 항목

| Field | English | 한국어 |
| --- | --- | --- |
| Choice text | What the player reads in the menu. | 메뉴에서 플레이어가 읽는 문장입니다. |
| Target node | Where the branch goes after selection. | 선택 후 분기가 향하는 노드입니다. |
| Condition | When the choice should appear. | 선택지가 표시될 조건입니다. |
| Action | What happens when the choice is selected. | 선택했을 때 실행되는 동작입니다. |

## Good Practice / 좋은 사용법

- Keep choice text short and readable.
- Make target nodes obvious in the tree.
- Put the most likely choice first.
- Use conditions only when the choice should truly stay hidden.
- Avoid using the same choice text for different outcomes unless the context is very clear.

## Common Mistakes / 흔한 실수

| Mistake | Result | Fix |
| --- | --- | --- |
| Wrong target node | The branch goes to the wrong place. | Recheck the node name or ID. |
| Hidden condition | The choice never appears. | Review the attached condition. |
| Long choice text | The menu becomes hard to scan. | Shorten the text and test it again. |

