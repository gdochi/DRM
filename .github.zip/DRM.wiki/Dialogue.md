# Dialogue / 다이얼로그

This page is the main hub for the Dialogue Editor.
이 페이지는 다이얼로그 에디터의 메인 허브입니다.

Use the section map below to jump around this page.
아래 섹션 맵으로 페이지 안에서 바로 이동할 수 있습니다.

## Section Map / 섹션 맵

| Section | English | 한국어 |
| --- | --- | --- |
| [Quick Start](#quick-start) | First safe path from opening the editor to exporting JSON. | 에디터를 열고 JSON을 내보내기까지의 가장 안전한 순서입니다. |
| [Node Flow](#node-flow) | How dialogue nodes connect and branch. | 대화 노드가 어떻게 연결되고 분기되는지 설명합니다. |
| [Choices](#choices) | Player choices and branch targets. | 플레이어 선택지와 분기 대상입니다. |
| [Conditions](#conditions) | Rules that control visibility and access. | 표시 여부와 접근을 제어하는 조건입니다. |
| [Actions](#actions) | Rewards, commands, sounds, and state changes. | 보상, 명령, 사운드, 상태 변경을 다룹니다. |
| [GUI Mapping](#gui-mapping) | Connects dialogue to a custom GUI. | 대화와 커스텀 GUI를 연결합니다. |
| [Troubleshooting](#troubleshooting) | Common errors and fixes. | 자주 나는 오류와 해결 방법입니다. |

## Quick Start

This is the shortest safe route from opening the editor to exporting a working dialogue.
이 항목은 에디터를 열고 동작하는 대화를 내보내기까지의 가장 안전한 경로입니다.

1. Open Dochi Editor inside a Minecraft world.
2. Choose `Dialogue Editor`.
3. Create a new dialogue set.
4. Add the opening node.
5. Write the first line of dialogue.
6. Add one or two choices first.
7. Connect each choice to a target node.
8. Export the dialogue JSON and test it in runtime.

Image slot: add a Quick Start screenshot here when you are ready.
이미지 자리: 준비되면 Quick Start 스크린샷을 이 위치에 넣으면 됩니다.

## Node Flow

Dialogue nodes are the backbone of the conversation tree.
대화 노드는 대화 트리의 뼈대입니다.

- One node should carry one clear moment in the conversation.
- Keep node IDs stable so references do not break later.
- Add branches only after the base path works.
- Use short, readable branch names.

Image slot: add a node tree screenshot here.
이미지 자리: 노드 트리 스크린샷을 여기에 넣으면 됩니다.

## Choices

Choices define what the player can pick and where each pick goes.
선택지는 플레이어가 무엇을 고를 수 있는지와 그 선택이 어디로 가는지를 정합니다.

- Keep choice labels short and readable.
- Make sure every choice points to the correct target node.
- Test one safe path before you add extra branches.
- Re-check ordering if the choice list grows large.

Image slot: add a choice editor screenshot here.
이미지 자리: 선택지 편집기 스크린샷을 여기에 넣으면 됩니다.

## Conditions

Conditions decide when a node or choice is visible and usable.
조건은 노드나 선택지가 언제 보이고 사용 가능한지 결정합니다.

- Use conditions for access rules, state checks, and progression gates.
- Name each condition so you can read it back later without guessing.
- Test both the allowed case and the blocked case.
- Keep the first version simple before stacking multiple rules.

Image slot: add a condition editor screenshot here.
이미지 자리: 조건 편집기 스크린샷을 여기에 넣으면 됩니다.

## Actions

Actions handle rewards, commands, sounds, and state changes.
액션은 보상, 명령, 사운드, 상태 변경을 처리합니다.

- Add actions after the main flow feels stable.
- Keep side effects easy to trace during testing.
- Check that rewards, commands, and flags all fire in the expected order.
- Re-test after every important action change.

Image slot: add an action editor screenshot here.
이미지 자리: 액션 편집기 스크린샷을 여기에 넣으면 됩니다.

## GUI Mapping

Use GUI Mapping when the dialogue must open or control a custom screen.
GUI Mapping은 대화가 커스텀 화면을 열거나 제어해야 할 때 사용합니다.

- Connect dialogue state to the screen state on purpose.
- Check that the dialogue still behaves correctly when the GUI closes.
- Keep a fallback path in case the custom screen is not available.
- Verify the player can return to the main flow cleanly.

Image slot: add a GUI mapping screenshot here.
이미지 자리: GUI 연결 스크린샷을 여기에 넣으면 됩니다.

## Troubleshooting

Use this section when something feels off during in-game testing.
인게임 테스트에서 이상해 보일 때 이 섹션부터 확인하면 됩니다.

- If a node is missing, check the target node name and ID.
- If a choice falls into the wrong branch, re-check the mapping.
- If a condition blocks too much, test each rule one by one.
- If actions do not fire, verify export order and runtime reload.

Image slot: add a debug screenshot here if it helps.
이미지 자리: 디버그용 스크린샷이 필요하면 여기에 넣으면 됩니다.

## Notes / 메모

- Keep English and Korean updated together.
- Keep examples short enough to scan quickly.
- Add screenshots directly in GitHub Wiki when you are ready.
- Use the sidebar to reach the deeper pages if you want more detail.
